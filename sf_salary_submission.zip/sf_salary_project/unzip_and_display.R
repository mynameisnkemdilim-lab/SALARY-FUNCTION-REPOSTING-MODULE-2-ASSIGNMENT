# =============================================================================
# unzip_and_display.R
# Task 6 – Unzip the "Employee Profile" folder and display the CSV data.
# =============================================================================

# ── 1. Configuration ──────────────────────────────────────────────────────────
zip_file   <- "Employee_Profile.zip"          # produced by the Python notebook
extract_to <- file.path(tempdir(), "EmployeeProfile")   # temp extraction folder

# ── 2. Validate zip exists ───────────────────────────────────────────────────
if (!file.exists(zip_file)) {
  stop(paste(
    "ZIP file not found:", zip_file,
    "\nPlease run the Python notebook first (Task 5) to generate it."
  ))
}

# ── 3. Unzip ──────────────────────────────────────────────────────────────────
message("Extracting: ", zip_file, " → ", extract_to)
unzip(zip_file, exdir = extract_to)
message("Extraction complete.")

# ── 4. Discover CSV files ─────────────────────────────────────────────────────
csv_files <- list.files(extract_to, pattern = "\\.csv$",
                        recursive = TRUE, full.names = TRUE)

if (length(csv_files) == 0) {
  stop("No CSV files found inside the ZIP archive.")
}

message("\nFound ", length(csv_files), " CSV file(s):\n",
        paste(" •", csv_files, collapse = "\n"))

# ── 5. Read and display each CSV ─────────────────────────────────────────────
all_data <- lapply(csv_files, function(path) {
  message("\n--- Reading: ", basename(path), " ---")
  df <- tryCatch(
    read.csv(path, stringsAsFactors = FALSE),
    error = function(e) {
      message("  ERROR reading file: ", e$message)
      return(NULL)
    }
  )
  if (!is.null(df)) {
    cat("\nDimensions :", nrow(df), "rows ×", ncol(df), "columns\n")
    cat("\nColumn names:\n")
    print(names(df))
    cat("\nSummary:\n")
    print(summary(df))
    cat("\nFull data:\n")
    print(df)
  }
  return(df)
})

# ── 6. Combine all files (if more than one) ───────────────────────────────────
combined <- do.call(rbind, Filter(Negate(is.null), all_data))

if (!is.null(combined) && nrow(combined) > 0) {
  cat("\n\n=== Combined dataset: ", nrow(combined),
      "row(s) from", length(csv_files), "file(s) ===\n")
  print(combined)
}

message("\n✅ R script completed successfully.")
